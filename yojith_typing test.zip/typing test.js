let timerEl = document.getElementById("timer");
let conEl = document.getElementById("con");
let quoteDisplayEl = document.getElementById("quoteDisplay");
let quoteInputEl = document.getElementById("quoteInput");
let submitBtnEl = document.getElementById("submitBtn");
let resetBtnEl = document.getElementById("resetBtn");
let resultEL = document.getElementById("result");
let spinnerEl = document.getElementById("spinner");

let uniqueId = null;
let uniqueid = null;

function add() {
    let url = "https://apis.ccbp.in/random-quote";
    let options = {
        method: "GET"
    };
    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            quoteDisplayEl.textContent = jsonData.content;
        });

    let counter = 0;
    uniqueId = setInterval(function() {
        timerEl.textContent = counter;
        counter = counter + 1;
    }, 1000);
}
add();

submitBtnEl.addEventListener("click", function() {
    let a = quoteDisplayEl.textContent;
    let b = quoteInputEl.value;
    if (a === b) {
        resultEL.classList.remove("d-none");
        resultEL.textContent = "You typed in " + timerEl.textContent + " seconds";
        clearInterval(uniqueId);
        clearInterval(uniqueid);
    } else {
        resultEL.classList.remove("d-none");
        resultEL.textContent = "You typed incorrect sentence";
    }
});

resetBtnEl.addEventListener("click", function() {
    clearInterval(uniqueId);
    clearInterval(uniqueid);
    spinnerEl.classList.remove("d-none");
    conEl.classList.add("d-none");
    quoteInputEl.value = "";

    function add_1() {
        let url = "https://apis.ccbp.in/random-quote";
        let options = {
            method: "GET"
        };
        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsonData) {
                quoteDisplayEl.textContent = jsonData.content;
            });

        let counter1 = 0;
        uniqueid = setInterval(function() {
            timerEl.textContent = counter1;
            counter1 = counter1 + 1;
        }, 1000);
        spinnerEl.classList.add("d-none");
        conEl.classList.remove("d-none");
        resultEL.textContent = "";
    }
    add_1();
});